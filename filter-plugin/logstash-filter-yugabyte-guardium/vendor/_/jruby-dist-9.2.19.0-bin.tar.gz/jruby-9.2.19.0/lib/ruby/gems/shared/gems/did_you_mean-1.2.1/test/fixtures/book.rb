class Book
  class Cover
  end
end
