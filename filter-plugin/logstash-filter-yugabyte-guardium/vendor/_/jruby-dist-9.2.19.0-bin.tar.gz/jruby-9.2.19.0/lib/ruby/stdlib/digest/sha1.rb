# Load built-in digest/sha1 library
JRuby::Util.load_ext("org.jruby.ext.digest.SHA1")
