# Load built-in bigdecimal library
JRuby::Util.load_ext("org.jruby.ext.bigdecimal.BigDecimalLibrary")
