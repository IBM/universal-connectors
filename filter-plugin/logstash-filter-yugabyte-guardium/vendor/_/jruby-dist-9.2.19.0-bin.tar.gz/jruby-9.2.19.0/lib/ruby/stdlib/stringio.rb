# Load built-in stringio library
JRuby::Util.load_ext("org.jruby.ext.stringio.StringIOLibrary")