# Load built-in coverage library
JRuby::Util.load_ext("org.jruby.ext.coverage.CoverageLibrary")
