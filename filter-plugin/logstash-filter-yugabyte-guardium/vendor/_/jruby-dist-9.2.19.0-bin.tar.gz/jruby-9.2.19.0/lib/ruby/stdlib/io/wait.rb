# Load built-in io/wait library
JRuby::Util.load_ext("org.jruby.ext.io.wait.IOWaitLibrary")
