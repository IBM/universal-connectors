module DidYouMean
  VERSION = "1.2.1"
end
