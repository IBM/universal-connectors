# Temporary stub file due to LOADED_FEATURES search not picking up short names
# See https://github.com/jruby/jruby/issues/5590
